import pandas as pd
import matplotlib.pyplot as plt
from sklearn import linear_model
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import PolynomialFeatures
import seaborn as sns

df_alq = pd.read_csv("data_alq_caba.csv", index_col="id")

# Variables explicativas
X1 = df_alq[["surface_total"]]

Y = df_alq[["price"]]

regression = linear_model.LinearRegression()
regression.fit(X1, Y)

print(regression.coef_)
print(regression.intercept_)
print(regression.score(X1, Y))
#%%

#Prediction

Y_pred = regression.predict(X1)
print(f"MSE: {mean_squared_error(Y, Y_pred)}")

plt.plot(X1.values, Y_pred, color="green")
plt.scatter(X1.values, Y.values, s=5)
plt.show()
plt.close()


#%%
X1 = df_alq[["surface_covered"]]

Y = df_alq[["surface_total"]]

regression = linear_model.LinearRegression()
regression.fit(X1, Y)

print(regression.coef_)
print(regression.intercept_)
print(regression.score(X1, Y))
#%%

#Prediction

Y_pred = regression.predict(X1)
print(f"MSE: {mean_squared_error(Y, Y_pred)}")

plt.plot(X1.values, Y_pred, color="red")
plt.scatter(X1.values, Y.values, s=5)
plt.show()
plt.close()

#%%

df_alq["fondo"] = df_alq["surface_total"] - df_alq["surface_covered"]

df_alq = df_alq[df_alq["fondo"] >= 0]

df_alq["start_date"] =  pd.to_datetime(df_alq["start_date"], format="%Y-%m-%d")
df_alq["anio"] = df_alq["start_date"].apply(lambda x : x.year)
df_alq["mes"] = df_alq["start_date"].apply(lambda x : x.month)


X1 = df_alq[["surface_total", "fondo", "anio", "mes"]]

Y = df_alq[["price"]]

regression = linear_model.LinearRegression()
regression.fit(X1, Y)

print(regression.coef_)
print(regression.intercept_)
print(regression.score(X1, Y))

Y_pred = regression.predict(X1)
print(f"MSE: {mean_squared_error(Y, Y_pred)}")

#%%

X1 = df_alq[["surface_total"]]
Y = df_alq[["price"]]

poly = PolynomialFeatures(4)
X = poly.fit_transform(X1)
Y = df_alq[["price"]]

regression = linear_model.LinearRegression()
regression.fit(X, Y)

print("Coeficientes:", regression.coef_)
print("Ordenada al origen:", regression.intercept_)
print(regression.score(X, Y))

Y_pred = regression.predict(X)
print(f"MSE: {mean_squared_error(Y, Y_pred)}")

plt.plot(X1.values, Y_pred, "rs", linewidth=.5)
plt.scatter(X1.values, Y.values, s=5)
plt.show()
plt.close()


#%%

# Testeamos los modelos

test = pd.read_csv('otra_data.csv', index_col = 'id')

X6 = test[['surface_total']]
X7 = poly.fit_transform(X6)

Y_pred7 = regression.predict(X7)
Y_posta = test[['price']]

#Bondad de ajuste
print("MSE del modelo polinomial, en test: %.2f" % mean_squared_error(Y_posta, Y_pred7))

